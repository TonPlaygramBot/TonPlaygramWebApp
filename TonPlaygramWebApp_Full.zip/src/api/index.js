// Placeholder for API client
export const fetchMiningStatus = async () => {};
