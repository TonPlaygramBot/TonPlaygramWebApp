// Placeholder for useAudio hook
export default function useAudio() {
  return { play: () => {} };
}
