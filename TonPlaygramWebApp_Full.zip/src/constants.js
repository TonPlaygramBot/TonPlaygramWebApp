export const API_BASE_URL = import.meta.env.VITE_PUBLIC_API_URL || 'http://localhost:5000';
export const TON_TO_TPC_RATE = 10000;
