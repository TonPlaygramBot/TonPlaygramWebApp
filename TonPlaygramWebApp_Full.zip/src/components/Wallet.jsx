// Placeholder for Wallet
export default function Wallet() {
  return <div>Wallet component</div>;
}
