// Placeholder for Leaderboard
export default function Leaderboard() {
  return <div>Leaderboard component</div>;
}
