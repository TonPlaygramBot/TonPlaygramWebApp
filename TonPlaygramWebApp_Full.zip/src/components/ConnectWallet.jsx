// Placeholder for ConnectWallet
export default function ConnectWallet() {
  return <div>ConnectWallet component</div>;
}
