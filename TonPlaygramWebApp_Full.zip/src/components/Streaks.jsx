// Placeholder for Streaks
export default function Streaks() {
  return <div>Streaks component</div>;
}
