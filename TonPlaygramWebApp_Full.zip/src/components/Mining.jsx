// Placeholder for Mining
export default function Mining() {
  return <div>Mining component</div>;
}
