// Placeholder for NFTGallery
export default function NFTGallery() {
  return <div>NFTGallery component</div>;
}
