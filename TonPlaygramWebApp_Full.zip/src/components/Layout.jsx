// Placeholder for Layout
export default function Layout() {
  return <div>Layout component</div>;
}
