// Placeholder for Dashboard
export default function Dashboard() {
  return <div>Dashboard component</div>;
}
