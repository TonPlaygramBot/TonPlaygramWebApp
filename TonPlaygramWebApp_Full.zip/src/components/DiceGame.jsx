// Placeholder for DiceGame
export default function DiceGame() {
  return <div>DiceGame component</div>;
}
