// Placeholder for SnakeLadder
export default function SnakeLadder() {
  return <div>SnakeLadder component</div>;
}
