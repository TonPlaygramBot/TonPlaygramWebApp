// Placeholder for WatchToEarn
export default function WatchToEarn() {
  return <div>WatchToEarn component</div>;
}
