// Placeholder for Tasks
export default function Tasks() {
  return <div>Tasks component</div>;
}
