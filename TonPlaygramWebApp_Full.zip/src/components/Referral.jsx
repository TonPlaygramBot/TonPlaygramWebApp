// Placeholder for Referral
export default function Referral() {
  return <div>Referral component</div>;
}
