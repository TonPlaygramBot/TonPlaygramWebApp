// Placeholder for LootBox
export default function LootBox() {
  return <div>LootBox component</div>;
}
