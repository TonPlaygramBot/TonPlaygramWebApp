// Placeholder model: Task.js
import mongoose from 'mongoose';
const schema = new mongoose.Schema({});
export default mongoose.model('Task', schema);
