// Placeholder model: Transaction.js
import mongoose from 'mongoose';
const schema = new mongoose.Schema({});
export default mongoose.model('Transaction', schema);
