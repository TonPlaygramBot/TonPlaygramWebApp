// Placeholder model: GameRoom.js
import mongoose from 'mongoose';
const schema = new mongoose.Schema({});
export default mongoose.model('GameRoom', schema);
